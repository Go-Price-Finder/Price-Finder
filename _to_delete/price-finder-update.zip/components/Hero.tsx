import SearchBar from "./SearchBar";
import RetailerFilterBar from "./RetailerFilterBar";
import { StoreIcon, TagIcon, TrendingUpIcon } from "./icons";

const STATS = [
  { icon: StoreIcon, value: "6,200+", label: "Stores tracked" },
  { icon: TagIcon, value: "2.4M+", label: "Prices compared daily" },
  { icon: TrendingUpIcon, value: "$180", label: "Average savings" },
];

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      {/* Soft decorative background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-24 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-gradient-to-b from-sage-100 via-cream-100 to-transparent blur-3xl" />
        <div className="absolute right-[-120px] top-40 h-72 w-72 rounded-full bg-clay-400/10 blur-3xl" />
      </div>

      <div className="mx-auto max-w-6xl px-5 pb-20 pt-16 text-center sm:px-8 sm:pb-28 sm:pt-24">
        <div className="animate-fade-up mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-sand-200 bg-white/70 px-4 py-1.5 text-xs font-medium text-ink-700 shadow-soft">
          <span className="h-1.5 w-1.5 rounded-full bg-sage-500" />
          Now tracking prices across 6,200+ stores
        </div>

        <h1 className="animate-fade-up text-balance font-display text-4xl font-medium leading-[1.1] tracking-tight text-ink-900 sm:text-6xl md:text-[68px]" style={{ animationDelay: "80ms" }}>
          Find it cheaper.
          <br />
          <span className="italic text-sage-600">Every time.</span>
        </h1>

        <p className="animate-fade-up mx-auto mt-6 max-w-xl text-balance text-base leading-relaxed text-ink-500 sm:text-lg" style={{ animationDelay: "160ms" }}>
          Price Finder scans thousands of retailers in real time so you never
          overpay again. Search once, compare everywhere.
        </p>

        <div className="animate-fade-up mx-auto mt-9 max-w-2xl" style={{ animationDelay: "240ms" }}>
          <SearchBar
            size="lg"
            placeholder="Try “wireless headphones” or “oak dining table”…"
          />

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            <RetailerFilterBar />
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs text-ink-500">
            <span>Popular:</span>
            {["Air fryers", "Standing desks", "Sneakers", "Skincare sets"].map(
              (term) => (
                <button
                  key={term}
                  className="rounded-full border border-sand-200 bg-white px-3 py-1 font-medium text-ink-700 transition-all duration-200 hover:border-sage-300 hover:bg-sage-50 hover:text-sage-700"
                >
                  {term}
                </button>
              )
            )}
          </div>
        </div>

        <div className="animate-fade-up mx-auto mt-16 grid max-w-2xl grid-cols-3 gap-4 sm:gap-8" style={{ animationDelay: "320ms" }}>
          {STATS.map(({ icon: Icon, value, label }) => (
            <div
              key={label}
              className="flex flex-col items-center gap-2 rounded-2xl border border-sand-200/70 bg-white/60 px-3 py-5 shadow-soft backdrop-blur-sm transition-transform duration-300 hover:-translate-y-1"
            >
              <Icon className="h-6 w-6 text-sage-600" />
              <span className="font-display text-xl font-medium text-ink-900 sm:text-2xl">
                {value}
              </span>
              <span className="text-center text-[11px] uppercase tracking-wide text-ink-500 sm:text-xs">
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
