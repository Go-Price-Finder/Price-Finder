"use client";

import { RetailerFilterProvider } from "@/lib/retailer-filter-context";
import { WishlistProvider } from "@/lib/wishlist-context";

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <WishlistProvider>
      <RetailerFilterProvider>{children}</RetailerFilterProvider>
    </WishlistProvider>
  );
}
