# Supabase setup

This folder holds the database schema for Price Finder's user accounts,
wishlists, and purchase history. It's independent of the loyalty-points
system, which will build on top of this once it exists.

## What's here

- `migrations/0001_initial_schema.sql` — the full schema: tables, enum,
  indexes, a spend-summary view, and Row Level Security policies. Fully
  commented with the reasoning behind each choice.
- `seed.sql` — populates `products` from the same catalog the frontend
  already uses (`lib/data.ts`), so wishlists/purchases have real products to
  reference. Safe to re-run.
- `example-queries.sql` — the two queries called out in the requirements
  ("all purchases by a user", "total spending"), plus a couple more, written
  against the indexes that make them fast.

## One-time setup

1. Create a project at [supabase.com](https://supabase.com) (free tier is
   fine to start).
2. In the Supabase dashboard, open **SQL Editor** and run
   `migrations/0001_initial_schema.sql`, then `seed.sql`. (If you use the
   [Supabase CLI](https://supabase.com/docs/guides/local-development)
   instead, `supabase link` to your project and run `supabase db push`.)
3. In **Settings → API**, copy the **Project URL** and **anon public** key.
4. In the app root, copy `.env.local.example` to `.env.local` and fill in
   those two values.
5. Restart `npm run dev` so Next.js picks up the new env vars.

That's it — `lib/supabase/client.ts` (browser) and `lib/supabase/server.ts`
(Server Components / Route Handlers / Server Actions) are ready to use, and
`middleware.ts` at the project root keeps auth sessions refreshed.

## Schema overview

| Table | Purpose | Key columns |
|---|---|---|
| `users` | 1:1 profile row per Supabase Auth user | `id` (= `auth.users.id`), `email`, `created_at` |
| `products` | Normalized product catalog | `id`, `name`, `category` |
| `wishlists` | Saved items per user, tagged by retailer | `user_id`, `product_id`, `retailer`, `price_saved` |
| `purchases` | Purchase history, append-only | `user_id`, `product_id`, `retailer`, `amount_spent`, `purchased_at` |

A few decisions worth calling out:

- **No password column, anywhere.** Supabase Auth's built-in `auth.users`
  table already stores email + a securely hashed password + `created_at`,
  and handles verification and password resets. `public.users` is a profile
  row keyed on that same `id` (auto-created by a trigger on signup) — it's
  what the rest of the schema references, but it never touches credentials.
- **Products are normalized**, not duplicated as free text on every
  wishlist/purchase row — both tables reference `products.id` by foreign
  key, which is what makes joins like "my purchases with product names"
  possible without redundant data.
- **Retailer is a Postgres enum** (`amazon`, `walmart`, `etsy`, `target`,
  `ebay`), matching the `RetailerId` type already used in the frontend
  (`lib/types.ts`) — so a bad retailer value is rejected at the database
  level, not just in the UI.
- **Indexing is built around the two queries in the requirements**: a
  composite index on `purchases (user_id, purchased_at desc)` covers "all
  purchases by a user" (already sorted, most recent first) in one index
  scan, and the `user_spending_summary` view pre-expresses the `SUM(...)
  GROUP BY user_id` for total spending. Extra indexes on `product_id` and
  `retailer` support the reporting queries you'll likely want next
  (top-purchased products, spend by retailer).
- **Row Level Security is on for every table.** Each user can only read/
  write their own `users`, `wishlists`, and `purchases` rows; `products` is
  public read-only catalog data. See the policy comments in the migration
  for the one caveat worth knowing about (client-side purchase inserts).
- **Purchases are treated as an append-only ledger** — no update/delete
  policy is granted, so once recorded, a purchase can't be edited or
  deleted by the user.

## What this doesn't include yet

- **Loyalty points** — intentionally left out per your note; the
  `user_spending_summary` view is the natural foundation to build it on
  (points are usually a function of total or recent spend), but no
  points/tier columns exist yet.
- **Wiring the existing UI to Supabase** — the current wishlist feature
  (`lib/wishlist-context.tsx`) still uses `localStorage`, and there's no
  sign-up/login UI yet. This task was scoped to the schema and typed query
  layer (`lib/supabase/queries.ts` has `getPurchasesByUser`,
  `getUserSpendingSummary`, `getWishlistByUser`, `addToWishlist`,
  `removeFromWishlist`, `recordPurchase` ready to call) — happy to wire up
  auth + swap the wishlist over to Supabase as a follow-up.
