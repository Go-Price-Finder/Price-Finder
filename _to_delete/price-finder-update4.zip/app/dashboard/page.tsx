import { redirect } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { createClient } from "@/lib/supabase/server";
import { getPurchasesByUser, getUserSpendingSummary } from "@/lib/supabase/queries";
import { formatPrice, getRetailer } from "@/lib/data";
import { ChevronRightIcon, StoreIcon, TagIcon, TrendingUpIcon } from "@/components/icons";

function formatDate(iso: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(new Date(iso));
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  const [profileResult, summary, purchases] = await Promise.all([
    supabase.from("users").select("*").eq("id", user.id).maybeSingle(),
    getUserSpendingSummary(supabase, user.id),
    getPurchasesByUser(supabase, user.id),
  ]);

  const profile = profileResult.data;
  const email = profile?.email ?? user.email ?? "";
  const memberSince = profile?.created_at ?? user.created_at;

  const stats = [
    {
      icon: TagIcon,
      value: formatPrice(summary?.total_spent ?? 0),
      label: "Total spent",
    },
    {
      icon: StoreIcon,
      value: String(summary?.purchase_count ?? 0),
      label: "Purchases",
    },
    {
      icon: TrendingUpIcon,
      value: summary?.last_purchase_at ? formatDate(summary.last_purchase_at) : "—",
      label: "Last purchase",
    },
  ];

  return (
    <>
      <Header />
      <main className="flex-1">
        <section className="mx-auto max-w-6xl px-5 py-12 sm:px-8 sm:py-16">
          {/* Profile card */}
          <div className="mb-10 flex flex-col items-start gap-5 rounded-3xl border border-sand-200/70 bg-white p-6 shadow-soft sm:flex-row sm:items-center sm:p-8">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-sage-100 font-display text-2xl font-medium text-sage-700">
              {email.charAt(0).toUpperCase() || "?"}
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-widest text-sage-600">
                Your account
              </span>
              <h1 className="mt-1 font-display text-2xl font-medium text-ink-900 sm:text-3xl">
                {email}
              </h1>
              <p className="mt-1 text-sm text-ink-500">
                Member since {formatDate(memberSince)}
              </p>
            </div>
          </div>

          {/* Spending stats */}
          <div className="mb-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
            {stats.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="flex flex-col items-center gap-2 rounded-2xl border border-sand-200/70 bg-white px-4 py-6 text-center shadow-soft transition-transform duration-300 hover:-translate-y-1"
              >
                <Icon className="h-6 w-6 text-sage-600" />
                <span className="font-display text-xl font-medium text-ink-900 sm:text-2xl">
                  {value}
                </span>
                <span className="text-[11px] uppercase tracking-wide text-ink-500 sm:text-xs">
                  {label}
                </span>
              </div>
            ))}
          </div>

          {/* Purchase history */}
          <div>
            <h2 className="mb-4 font-display text-xl font-medium text-ink-900">
              Purchase history
            </h2>

            {purchases.length === 0 ? (
              <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-sand-200 bg-sand-100/40 px-6 py-16 text-center">
                <p className="font-display text-lg font-medium text-ink-900">
                  No purchases yet
                </p>
                <p className="max-w-sm text-sm text-ink-500">
                  Once you buy something through Price Finder, it&apos;ll
                  show up here with the retailer and price you paid.
                </p>
                <Link
                  href="/#trending"
                  className="group mt-1 inline-flex items-center gap-1 rounded-full bg-ink-900 px-5 py-2.5 text-sm font-medium text-cream-50 transition-colors hover:bg-sage-600"
                >
                  Browse trending products
                  <ChevronRightIcon className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </Link>
              </div>
            ) : (
              <div className="overflow-hidden rounded-3xl border border-sand-200 bg-white shadow-soft">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[640px] border-collapse text-left">
                    <thead>
                      <tr className="border-b border-sand-200 bg-sand-100/50 text-xs font-semibold uppercase tracking-wide text-ink-500">
                        <th className="px-5 py-3 font-semibold">Product</th>
                        <th className="px-5 py-3 font-semibold">Retailer</th>
                        <th className="px-5 py-3 font-semibold">Amount</th>
                        <th className="px-5 py-3 font-semibold">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {purchases.map((purchase) => {
                        const retailer = getRetailer(purchase.retailer);
                        return (
                          <tr
                            key={purchase.id}
                            className="border-b border-sand-100 transition-colors last:border-0 hover:bg-sand-100/30"
                          >
                            <td className="px-5 py-4">
                              <div className="flex items-center gap-3">
                                {purchase.products?.image_url && (
                                  <Image
                                    src={purchase.products.image_url}
                                    alt={purchase.products.name}
                                    width={48}
                                    height={48}
                                    className="h-12 w-12 shrink-0 rounded-xl object-cover"
                                  />
                                )}
                                <p className="line-clamp-2 max-w-[220px] font-display text-sm font-medium text-ink-900">
                                  {purchase.products?.name ?? "Unknown product"}
                                </p>
                              </div>
                            </td>
                            <td className="px-5 py-4">
                              <span
                                className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${retailer.badgeClass}`}
                              >
                                {retailer.name}
                              </span>
                            </td>
                            <td className="px-5 py-4 font-display text-sm font-semibold text-ink-900">
                              {formatPrice(purchase.amount_spent)}
                            </td>
                            <td className="px-5 py-4 text-sm text-ink-500">
                              {formatDate(purchase.purchased_at)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
