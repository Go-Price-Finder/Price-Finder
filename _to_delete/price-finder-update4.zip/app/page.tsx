import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrendingNow from "@/components/TrendingNow";
import PopularCategories from "@/components/PopularCategories";
import HowItWorks from "@/components/HowItWorks";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <Hero />
        <TrendingNow />
        <PopularCategories />
        <HowItWorks />
      </main>
      <Footer />
    </>
  );
}
