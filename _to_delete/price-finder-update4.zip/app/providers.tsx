"use client";

import { AuthProvider } from "@/lib/auth-context";
import { RetailerFilterProvider } from "@/lib/retailer-filter-context";
import { WishlistProvider } from "@/lib/wishlist-context";

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <WishlistProvider>
        <RetailerFilterProvider>{children}</RetailerFilterProvider>
      </WishlistProvider>
    </AuthProvider>
  );
}
