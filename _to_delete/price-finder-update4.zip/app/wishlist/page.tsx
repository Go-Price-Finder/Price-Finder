"use client";

import Link from "next/link";
import Image from "next/image";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PriceHistorySparkline from "@/components/PriceHistorySparkline";
import { HeartIcon, StarIcon, ChevronRightIcon } from "@/components/icons";
import { useWishlist } from "@/lib/wishlist-context";
import { trendingProducts, formatPrice, getRetailer } from "@/lib/data";

export default function WishlistPage() {
  const { ids, remove, clear } = useWishlist();
  const items = trendingProducts.filter((p) => ids.includes(p.id));

  return (
    <>
      <Header />
      <main className="flex-1">
        <section className="mx-auto max-w-6xl px-5 py-12 sm:px-8 sm:py-16">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="text-xs font-semibold uppercase tracking-widest text-sage-600">
                Your picks
              </span>
              <h1 className="mt-2 font-display text-3xl font-medium tracking-tight text-ink-900 sm:text-4xl">
                Wishlist
              </h1>
              <p className="mt-2 text-sm text-ink-500">
                {items.length === 0
                  ? "Nothing saved yet."
                  : `Comparing ${items.length} item${items.length === 1 ? "" : "s"} across retailers, side by side.`}
              </p>
            </div>
            {items.length > 0 && (
              <button
                onClick={clear}
                className="rounded-full border border-sand-200 bg-white px-4 py-2 text-sm font-medium text-ink-700 shadow-soft transition-all duration-200 hover:border-ink-900/20 hover:text-ink-900"
              >
                Clear wishlist
              </button>
            )}
          </div>

          {items.length === 0 ? (
            <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-sand-200 bg-sand-100/40 px-6 py-20 text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-clay-500 shadow-soft">
                <HeartIcon className="h-6 w-6" />
              </span>
              <p className="font-display text-lg font-medium text-ink-900">
                Your wishlist is empty
              </p>
              <p className="max-w-sm text-sm text-ink-500">
                Tap the heart icon on any product to save it here and compare
                prices across retailers later.
              </p>
              <Link
                href="/#trending"
                className="group mt-1 inline-flex items-center gap-1 rounded-full bg-ink-900 px-5 py-2.5 text-sm font-medium text-cream-50 transition-colors hover:bg-sage-600"
              >
                Browse trending products
                <ChevronRightIcon className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </Link>
            </div>
          ) : (
            <div className="overflow-hidden rounded-3xl border border-sand-200 bg-white shadow-soft">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px] border-collapse text-left">
                  <thead>
                    <tr className="border-b border-sand-200 bg-sand-100/50 text-xs font-semibold uppercase tracking-wide text-ink-500">
                      <th className="px-5 py-3 font-semibold">Product</th>
                      <th className="px-5 py-3 font-semibold">Retailer</th>
                      <th className="px-5 py-3 font-semibold">Price</th>
                      <th className="px-5 py-3 font-semibold">Rating</th>
                      <th className="px-5 py-3 font-semibold">6-month trend</th>
                      <th className="px-5 py-3 font-semibold text-right">Remove</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((product) => {
                      const retailer = getRetailer(product.retailer);
                      return (
                        <tr
                          key={product.id}
                          className="border-b border-sand-100 transition-colors last:border-0 hover:bg-sand-100/30"
                        >
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <Image
                                src={product.image}
                                alt={product.name}
                                width={56}
                                height={56}
                                className="h-14 w-14 shrink-0 rounded-xl object-cover"
                              />
                              <div>
                                <p className="line-clamp-2 max-w-[220px] font-display text-sm font-medium text-ink-900">
                                  {product.name}
                                </p>
                                <p className="text-xs text-ink-400">
                                  {product.category}
                                </p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span
                              className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${retailer.badgeClass}`}
                            >
                              {retailer.name}
                            </span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-baseline gap-2">
                              <span
                                className={`font-display text-base font-semibold ${
                                  product.isBestPrice ? "text-sage-600" : "text-ink-900"
                                }`}
                              >
                                {formatPrice(product.currentPrice)}
                              </span>
                              {product.originalPrice && (
                                <span className="text-xs text-ink-300 line-through">
                                  {formatPrice(product.originalPrice)}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1 text-xs text-ink-500">
                              <StarIcon className="h-3.5 w-3.5 text-clay-500" />
                              <span className="font-medium text-ink-700">
                                {product.rating}
                              </span>
                              <span>({product.reviewCount.toLocaleString()})</span>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <PriceHistorySparkline
                              history={product.priceHistory}
                              className="h-6 w-[100px]"
                            />
                          </td>
                          <td className="px-5 py-4 text-right">
                            <button
                              onClick={() => remove(product.id)}
                              aria-label={`Remove ${product.name} from wishlist`}
                              className="rounded-full border border-sand-200 px-3 py-1.5 text-xs font-medium text-ink-500 transition-colors hover:border-clay-400 hover:text-clay-500"
                            >
                              Remove
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </section>
      </main>
      <Footer />
    </>
  );
}
