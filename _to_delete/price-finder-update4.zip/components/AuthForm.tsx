"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { signInAction, signUpAction } from "@/lib/supabase/actions";

export default function AuthForm({
  mode,
  redirectTo,
}: {
  mode: "login" | "signup";
  /** Where to send the user after a successful login (e.g. the page they
   *  were bounced from by middleware.ts). Ignored in signup mode. */
  redirectTo?: string;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const isSignup = mode === "signup";

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      const result = isSignup
        ? await signUpAction(email, password)
        : await signInAction(email, password, redirectTo);
      if (result?.error) setError(result.error);
    });
  }

  return (
    <div className="mx-auto w-full max-w-md rounded-3xl border border-sand-200/70 bg-white p-8 shadow-soft-xl sm:p-10">
      <h1 className="font-display text-2xl font-medium text-ink-900">
        {isSignup ? "Create your account" : "Welcome back"}
      </h1>
      <p className="mt-2 text-sm leading-relaxed text-ink-500">
        {isSignup
          ? "Save items across retailers, track price history, and see your spending in one place."
          : "Log in to see your wishlist, purchase history, and total spending."}
      </p>

      <form onSubmit={handleSubmit} noValidate className="mt-8 flex flex-col gap-4">
        {error && (
          <div
            role="alert"
            className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
          >
            {error}
          </div>
        )}

        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium uppercase tracking-wide text-ink-500">
            Email
          </span>
          <input
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="rounded-2xl border border-sand-200 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-300 transition-all duration-200 focus:border-sage-400 focus:outline-none focus:ring-4 focus:ring-sage-100"
          />
        </label>

        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium uppercase tracking-wide text-ink-500">
            Password
          </span>
          <input
            type="password"
            required
            minLength={6}
            autoComplete={isSignup ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="rounded-2xl border border-sand-200 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-300 transition-all duration-200 focus:border-sage-400 focus:outline-none focus:ring-4 focus:ring-sage-100"
          />
          {isSignup && (
            <span className="mt-0.5 text-xs text-ink-400">
              At least 6 characters.
            </span>
          )}
        </label>

        <button
          type="submit"
          disabled={isPending}
          className="mt-2 flex items-center justify-center rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-cream-50 transition-all duration-200 hover:bg-sage-600 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {isPending
            ? isSignup
              ? "Creating account…"
              : "Signing in…"
            : isSignup
              ? "Create account"
              : "Sign in"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-ink-500">
        {isSignup ? (
          <>
            Already have an account?{" "}
            <Link
              href="/auth/login"
              className="font-medium text-sage-600 transition-colors hover:text-sage-700"
            >
              Sign in
            </Link>
          </>
        ) : (
          <>
            New to Price Finder?{" "}
            <Link
              href="/auth/signup"
              className="font-medium text-sage-600 transition-colors hover:text-sage-700"
            >
              Create an account
            </Link>
          </>
        )}
      </p>
    </div>
  );
}
