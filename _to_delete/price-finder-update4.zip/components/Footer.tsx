import Link from "next/link";
import Logo from "./Logo";
import SearchBar from "./SearchBar";

const FOOTER_LINKS: { title: string; links: string[] }[] = [
  {
    title: "Shop",
    links: ["Trending", "Categories", "Deals", "Price Alerts"],
  },
  {
    title: "Company",
    links: ["About Us", "How It Works", "Careers", "Press"],
  },
  {
    title: "Support",
    links: ["Help Center", "Contact Us", "Privacy Policy", "Terms of Service"],
  },
];

export default function Footer() {
  return (
    <footer className="mt-auto border-t border-sand-200 bg-cream-100">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_repeat(3,1fr)]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-ink-500">
              Compare prices across thousands of stores and always shop
              smarter, never overpay again.
            </p>

            <div className="mt-6 max-w-sm">
              <p className="mb-2 text-sm font-medium text-ink-700">
                Get price drop alerts
              </p>
              <SearchBar
                placeholder="Enter your email"
                buttonLabel="Subscribe"
                showIcon={false}
              />
            </div>
          </div>

          {FOOTER_LINKS.map((group) => (
            <div key={group.title}>
              <h4 className="text-sm font-semibold text-ink-900">
                {group.title}
              </h4>
              <ul className="mt-4 space-y-3">
                {group.links.map((link) => (
                  <li key={link}>
                    <Link
                      href="#"
                      className="text-sm text-ink-500 transition-colors hover:text-sage-600"
                    >
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-sand-200 pt-8 sm:flex-row">
          <p className="text-xs text-ink-400">
            © {new Date().getFullYear()} Price Finder. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            {["Twitter", "Instagram", "LinkedIn"].map((social) => (
              <a
                key={social}
                href="#"
                className="text-xs font-medium text-ink-500 transition-colors hover:text-sage-600"
              >
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
