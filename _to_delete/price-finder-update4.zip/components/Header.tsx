"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import Logo from "./Logo";
import SearchBar from "./SearchBar";
import { BellIcon, CloseIcon, HeartIcon, MenuIcon } from "./icons";
import { useWishlist } from "@/lib/wishlist-context";
import { useAuth } from "@/lib/auth-context";
import { signOutAction } from "@/lib/supabase/actions";

const NAV_LINKS = [
  { label: "Trending", href: "#trending" },
  { label: "Categories", href: "#categories" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Deals", href: "#" },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { count } = useWishlist();
  const { user, loading } = useAuth();
  const [signingOut, startSignOut] = useTransition();

  function handleSignOut() {
    startSignOut(async () => {
      await signOutAction();
    });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-sand-200/70 bg-cream-50/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-5 py-4 sm:px-8">
        <Link href="/" className="shrink-0">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="relative text-sm font-medium text-ink-700 transition-colors hover:text-ink-900 after:absolute after:-bottom-1 after:left-0 after:h-[1.5px] after:w-0 after:bg-sage-500 after:transition-all after:duration-300 hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden max-w-md flex-1 md:block">
          <SearchBar />
        </div>

        <div className="ml-auto hidden items-center gap-3 lg:flex">
          <Link
            href="/wishlist"
            aria-label={`Wishlist, ${count} saved item${count === 1 ? "" : "s"}`}
            className="relative flex h-10 w-10 items-center justify-center rounded-full text-ink-700 transition-colors hover:bg-sand-100 hover:text-ink-900"
          >
            <HeartIcon className="h-5 w-5" filled={count > 0} />
            {count > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-sage-500 px-1 text-[10px] font-semibold text-white">
                {count}
              </span>
            )}
          </Link>
          <button
            aria-label="Notifications"
            className="flex h-10 w-10 items-center justify-center rounded-full text-ink-700 transition-colors hover:bg-sand-100 hover:text-ink-900"
          >
            <BellIcon className="h-5 w-5" />
          </button>

          {loading ? (
            <div className="h-10 w-24 animate-pulse rounded-full bg-sand-100" />
          ) : user ? (
            <div className="flex items-center gap-2">
              <Link
                href="/dashboard"
                className="flex items-center gap-2 rounded-full border border-ink-900/10 py-1.5 pl-1.5 pr-4 text-sm font-medium text-ink-900 transition-all duration-200 hover:border-sage-300 hover:bg-sage-50"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-sage-100 text-xs font-semibold text-sage-700">
                  {user.email?.charAt(0).toUpperCase() ?? "?"}
                </span>
                Dashboard
              </Link>
              <button
                onClick={handleSignOut}
                disabled={signingOut}
                className="rounded-full border border-ink-900/10 px-4 py-2.5 text-sm font-medium text-ink-700 transition-all duration-200 hover:border-transparent hover:bg-ink-900 hover:text-cream-50 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {signingOut ? "Logging out…" : "Log out"}
              </button>
            </div>
          ) : (
            <Link
              href="/auth/login"
              className="rounded-full border border-ink-900/10 px-5 py-2.5 text-sm font-medium text-ink-900 transition-all duration-300 hover:border-transparent hover:bg-ink-900 hover:text-cream-50"
            >
              Sign In
            </Link>
          )}
        </div>

        <div className="ml-auto flex items-center gap-1 lg:hidden">
          <Link
            href="/wishlist"
            aria-label={`Wishlist, ${count} saved item${count === 1 ? "" : "s"}`}
            className="relative flex h-10 w-10 items-center justify-center rounded-full text-ink-900 transition-colors hover:bg-sand-100"
          >
            <HeartIcon className="h-5 w-5" filled={count > 0} />
            {count > 0 && (
              <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-sage-500 px-1 text-[10px] font-semibold text-white">
                {count}
              </span>
            )}
          </Link>
          <button
            aria-label="Toggle menu"
            onClick={() => setMenuOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-ink-900 transition-colors hover:bg-sand-100"
          >
            {menuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>

      {/* Mobile search, always visible under 768px */}
      <div className="px-5 pb-4 md:hidden">
        <SearchBar />
      </div>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-out lg:hidden ${
          menuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="flex flex-col gap-1 border-t border-sand-200/70 bg-cream-50 px-5 py-4">
          {NAV_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="rounded-xl px-3 py-3 text-sm font-medium text-ink-700 transition-colors hover:bg-sand-100 hover:text-ink-900"
            >
              {link.label}
            </a>
          ))}

          {loading ? (
            <div className="mt-2 h-11 animate-pulse rounded-full bg-sand-100" />
          ) : user ? (
            <>
              <Link
                href="/dashboard"
                onClick={() => setMenuOpen(false)}
                className="mt-2 rounded-full bg-sage-50 px-5 py-3 text-center text-sm font-medium text-sage-700 transition-colors hover:bg-sage-100"
              >
                Dashboard
              </Link>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  handleSignOut();
                }}
                disabled={signingOut}
                className="rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-cream-50 transition-colors hover:bg-sage-600 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {signingOut ? "Logging out…" : "Log out"}
              </button>
            </>
          ) : (
            <Link
              href="/auth/login"
              onClick={() => setMenuOpen(false)}
              className="mt-2 rounded-full bg-ink-900 px-5 py-3 text-center text-sm font-medium text-cream-50 transition-colors hover:bg-sage-600"
            >
              Sign In
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
