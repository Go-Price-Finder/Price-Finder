import { SearchIcon, TagIcon, TrendingUpIcon } from "./icons";

const STEPS = [
  {
    icon: SearchIcon,
    title: "Search any product",
    description:
      "Type in what you're looking for — a brand, a model, or just a description. Our engine finds every listing that matches.",
  },
  {
    icon: TagIcon,
    title: "Compare real-time prices",
    description:
      "We scan thousands of retailers instantly and lay out every price side by side, with shipping and fees included.",
  },
  {
    icon: TrendingUpIcon,
    title: "Buy at the best price",
    description:
      "Click through to the lowest total price, or set an alert and we'll notify you the moment it drops further.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="mb-14 text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-sage-600">
            Simple &amp; fast
          </span>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight text-ink-900 sm:text-4xl">
            How Price Finder works
          </h2>
        </div>

        <div className="relative grid gap-8 sm:grid-cols-3 sm:gap-6">
          <div
            className="pointer-events-none absolute left-0 right-0 top-9 hidden h-px bg-gradient-to-r from-transparent via-sand-200 to-transparent sm:block"
            aria-hidden
          />

          {STEPS.map((step, index) => (
            <div
              key={step.title}
              className="group relative flex flex-col items-center rounded-3xl border border-transparent px-6 py-8 text-center transition-all duration-300 hover:border-sand-200 hover:bg-white hover:shadow-soft-lg"
            >
              <div className="relative flex h-[72px] w-[72px] items-center justify-center rounded-full bg-sage-50 text-sage-600 shadow-soft transition-all duration-300 group-hover:scale-105 group-hover:bg-sage-500 group-hover:text-white">
                <step.icon className="h-7 w-7" />
                <span className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-ink-900 text-[11px] font-semibold text-cream-50">
                  {index + 1}
                </span>
              </div>
              <h3 className="mt-5 font-display text-xl font-medium text-ink-900">
                {step.title}
              </h3>
              <p className="mt-2 text-balance text-sm leading-relaxed text-ink-500">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
