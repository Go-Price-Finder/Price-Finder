export default function Logo({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-2 font-display text-xl font-medium tracking-tight text-ink-900 ${className}`}
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-sage-500 text-cream-50 shadow-soft">
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12 2L14.4 8.6L21 11L14.4 13.4L12 20L9.6 13.4L3 11L9.6 8.6L12 2Z"
            fill="currentColor"
          />
        </svg>
      </span>
      Price Finder
    </span>
  );
}
