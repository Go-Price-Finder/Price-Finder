import Image from "next/image";
import { categories } from "@/lib/data";

export default function PopularCategories() {
  return (
    <section id="categories" className="bg-sand-100/50 py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mb-10 text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-sage-600">
            Browse
          </span>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight text-ink-900 sm:text-4xl">
            Popular categories
          </h2>
          <p className="mx-auto mt-3 max-w-md text-balance text-ink-500">
            Explore curated collections and find the best prices in every
            corner of your home.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-3">
          {categories.map((category, i) => (
            <a
              key={category.id}
              href="#"
              className={`group relative flex aspect-[4/5] overflow-hidden rounded-3xl shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-soft-xl sm:aspect-[4/4.2] ${
                i === 0 ? "col-span-2 aspect-[16/9] sm:col-span-1 sm:aspect-[4/4.2]" : ""
              }`}
            >
              <Image
                src={category.image}
                alt={category.name}
                fill
                sizes="(max-width: 640px) 50vw, 33vw"
                className="object-cover transition-transform duration-500 ease-out group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900/70 via-ink-900/10 to-transparent" />
              <div className="relative mt-auto flex w-full flex-col gap-1 p-5">
                <h3 className="font-display text-lg font-medium text-white sm:text-xl">
                  {category.name}
                </h3>
                <span className="text-xs font-medium text-white/80">
                  {category.itemCount}
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
