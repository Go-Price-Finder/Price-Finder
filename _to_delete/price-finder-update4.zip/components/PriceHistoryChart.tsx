"use client";

import { useState } from "react";
import { PricePoint } from "@/lib/types";
import { formatPrice, formatShortDate, analyzePriceHistory } from "@/lib/data";
import { buildAreaPath, buildLinePath, scalePoints } from "@/lib/chart-utils";

const WIDTH = 480;
const HEIGHT = 180;
const PAD_X = 8;

export default function PriceHistoryChart({ history }: { history: PricePoint[] }) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const points = scalePoints(history, WIDTH - PAD_X * 2, HEIGHT, 14).map((p) => ({
    ...p,
    x: p.x + PAD_X,
  }));
  const { min, max, isDown, isFlat } = analyzePriceHistory(history);
  const strokeColor = isFlat ? "#6b6660" : isDown ? "#3a7a46" : "#c97f5c";

  const active = hoverIndex !== null ? points[hoverIndex] : null;

  function handleMove(e: React.PointerEvent<SVGSVGElement>) {
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const relX = ((e.clientX - rect.left) / rect.width) * WIDTH;
    // Find nearest point by x distance.
    let closest = 0;
    let closestDist = Infinity;
    points.forEach((p, i) => {
      const dist = Math.abs(p.x - relX);
      if (dist < closestDist) {
        closestDist = dist;
        closest = i;
      }
    });
    setHoverIndex(closest);
  }

  return (
    <div className="w-full">
      <div className="mb-2 flex items-center justify-between text-xs text-ink-500">
        <span>{formatPrice(max)}</span>
        <span className="font-medium text-ink-300">Highest tracked price</span>
      </div>

      <svg
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        className="w-full touch-none"
        role="img"
        aria-label="Price history chart for the last 6 months"
        onPointerMove={handleMove}
        onPointerLeave={() => setHoverIndex(null)}
      >
        <defs>
          <linearGradient id="price-history-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={strokeColor} stopOpacity="0.16" />
            <stop offset="100%" stopColor={strokeColor} stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Recessive gridlines */}
        {[0.25, 0.5, 0.75].map((f) => (
          <line
            key={f}
            x1={PAD_X}
            x2={WIDTH - PAD_X}
            y1={HEIGHT * f}
            y2={HEIGHT * f}
            stroke="#e6dfd0"
            strokeWidth="1"
          />
        ))}

        <path d={buildAreaPath(points, HEIGHT)} fill="url(#price-history-fill)" />
        <path
          d={buildLinePath(points)}
          fill="none"
          stroke={strokeColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {points.map((p, i) => (
          <circle
            key={p.date}
            cx={p.x}
            cy={p.y}
            r={i === hoverIndex ? 4.5 : 2.5}
            fill={strokeColor}
            className="transition-all duration-100"
          />
        ))}

        {active && (
          <line
            x1={active.x}
            x2={active.x}
            y1={0}
            y2={HEIGHT}
            stroke={strokeColor}
            strokeWidth="1"
            strokeDasharray="3 3"
            opacity="0.5"
          />
        )}
      </svg>

      <div className="mt-2 flex items-center justify-between text-xs text-ink-500">
        <span>{formatShortDate(history[0]?.date ?? "")}</span>
        <span className="font-medium text-ink-300">
          {formatPrice(min)} lowest tracked price
        </span>
        <span>{formatShortDate(history[history.length - 1]?.date ?? "")}</span>
      </div>

      {/* Tooltip / readout, always rendered (not color-only) so it works without hover on touch */}
      <div className="mt-4 flex items-center justify-between rounded-xl border border-sand-200 bg-sand-100/60 px-4 py-3">
        <span className="text-xs font-medium text-ink-500">
          {active ? formatShortDate(active.date) : "Hover the chart to inspect a date"}
        </span>
        <span className="font-display text-lg font-semibold text-ink-900">
          {active ? formatPrice(active.price) : "—"}
        </span>
      </div>
    </div>
  );
}
