import { PricePoint } from "@/lib/types";
import { analyzePriceHistory } from "@/lib/data";
import { buildAreaPath, buildLinePath, scalePoints } from "@/lib/chart-utils";

const WIDTH = 120;
const HEIGHT = 32;

export default function PriceHistorySparkline({
  history,
  className = "",
}: {
  history: PricePoint[];
  className?: string;
}) {
  const points = scalePoints(history, WIDTH, HEIGHT);
  const { isDown, isFlat } = analyzePriceHistory(history);
  const strokeColor = isFlat ? "#a39d94" : isDown ? "#3a7a46" : "#c97f5c";

  return (
    <svg
      viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
      className={className}
      role="img"
      aria-label="Price history over the last 6 months"
      preserveAspectRatio="none"
    >
      <defs>
        <linearGradient id="sparkline-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={strokeColor} stopOpacity="0.18" />
          <stop offset="100%" stopColor={strokeColor} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={buildAreaPath(points, HEIGHT)} fill="url(#sparkline-fill)" />
      <path
        d={buildLinePath(points)}
        fill="none"
        stroke={strokeColor}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {points.length > 0 && (
        <circle
          cx={points[points.length - 1].x}
          cy={points[points.length - 1].y}
          r="2.5"
          fill={strokeColor}
        />
      )}
    </svg>
  );
}
