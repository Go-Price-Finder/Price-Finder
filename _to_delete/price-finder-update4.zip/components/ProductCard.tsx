"use client";

import { useState } from "react";
import Image from "next/image";
import { Product } from "@/lib/types";
import { analyzePriceHistory, formatPrice, getRetailer } from "@/lib/data";
import { useTilt } from "@/lib/use-tilt";
import { StarIcon, HistoryIcon } from "./icons";
import PriceHistorySparkline from "./PriceHistorySparkline";
import PriceHistoryChart from "./PriceHistoryChart";
import WishlistButton from "./WishlistButton";
import Modal from "./Modal";

export default function ProductCard({ product }: { product: Product }) {
  const [historyOpen, setHistoryOpen] = useState(false);
  const retailer = getRetailer(product.retailer);
  const { changePct, isDown, isFlat } = analyzePriceHistory(product.priceHistory);
  const tilt = useTilt<HTMLElement>();

  const discount =
    product.originalPrice && product.originalPrice > product.currentPrice
      ? Math.round(
          ((product.originalPrice - product.currentPrice) /
            product.originalPrice) *
            100
        )
      : null;

  return (
    <>
      <article
        ref={tilt.ref}
        onPointerMove={tilt.onPointerMove}
        onPointerLeave={tilt.onPointerLeave}
        className="group relative flex w-[260px] shrink-0 flex-col overflow-hidden rounded-3xl border border-sand-200/70 bg-white shadow-soft transition-[transform,box-shadow] duration-200 ease-out will-change-transform hover:shadow-soft-xl sm:w-[280px]"
      >
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-sand-100">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="280px"
            className="object-cover transition-transform duration-500 ease-out group-hover:scale-105"
          />

          {product.isBestPrice && (
            <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-sage-500 px-2.5 py-1 text-[11px] font-semibold text-white shadow-soft">
              <span className="h-1.5 w-1.5 rounded-full bg-white" />
              Best Price
            </span>
          )}

          {discount && (
            <span className="absolute right-3 top-3 rounded-full bg-ink-900/90 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur-sm">
              −{discount}%
            </span>
          )}

          <WishlistButton
            productId={product.id}
            className="absolute bottom-3 right-3"
          />
        </div>

        <div className="flex flex-1 flex-col gap-2 p-4">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-medium uppercase tracking-wide text-ink-300">
              {product.category}
            </span>
            <span
              className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${retailer.badgeClass}`}
            >
              {retailer.name}
            </span>
          </div>

          <h3 className="line-clamp-2 font-display text-base font-medium leading-snug text-ink-900">
            {product.name}
          </h3>

          <div className="flex items-center gap-1 text-xs text-ink-500">
            <StarIcon className="h-3.5 w-3.5 text-clay-500" />
            <span className="font-medium text-ink-700">{product.rating}</span>
            <span>({product.reviewCount.toLocaleString()})</span>
          </div>

          <div className="mt-1 flex items-end justify-between">
            <div className="flex items-baseline gap-2">
              <span
                className={`font-display text-xl font-semibold ${
                  product.isBestPrice ? "text-sage-600" : "text-ink-900"
                }`}
              >
                {formatPrice(product.currentPrice)}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-ink-300 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={() => setHistoryOpen(true)}
            className="group/history mt-1 flex items-center gap-2 rounded-xl border border-sand-100 bg-sand-100/40 px-2.5 py-2 text-left transition-colors hover:border-sage-200 hover:bg-sage-50"
          >
            <PriceHistorySparkline
              history={product.priceHistory}
              className="h-6 w-[76px] shrink-0"
            />
            <span className="flex flex-1 flex-col leading-tight">
              <span
                className={`text-xs font-semibold ${
                  isFlat
                    ? "text-ink-500"
                    : isDown
                      ? "text-sage-600"
                      : "text-clay-500"
                }`}
              >
                {isFlat ? "Steady" : `${isDown ? "▼" : "▲"} ${Math.abs(changePct).toFixed(0)}%`}{" "}
                <span className="font-normal text-ink-400">/ 6mo</span>
              </span>
              <span className="flex items-center gap-1 text-[11px] text-ink-400 transition-colors group-hover/history:text-sage-600">
                <HistoryIcon className="h-3 w-3" />
                View price history
              </span>
            </span>
          </button>

          <div className="mt-1 flex items-center justify-between border-t border-sand-100 pt-3 text-xs text-ink-500">
            <span>
              at <span className="font-medium text-ink-700">{product.store}</span>
            </span>
            <span>{product.storesTracked} stores</span>
          </div>
        </div>
      </article>

      <Modal
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        title="Price history"
        subtitle={product.name}
      >
        <PriceHistoryChart history={product.priceHistory} />
      </Modal>
    </>
  );
}
