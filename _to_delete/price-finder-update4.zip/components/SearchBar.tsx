"use client";

import { useState } from "react";
import { SearchIcon } from "./icons";

type SearchBarProps = {
  size?: "md" | "lg";
  placeholder?: string;
  className?: string;
  buttonLabel?: string;
  showIcon?: boolean;
};

export default function SearchBar({
  size = "md",
  placeholder = "Search for any product, brand, or store…",
  className = "",
  buttonLabel = "Search",
  showIcon = true,
}: SearchBarProps) {
  const [value, setValue] = useState("");
  const [focused, setFocused] = useState(false);

  const isLarge = size === "lg";

  return (
    <div className="relative">
      {focused && (
        <span
          aria-hidden
          className="animate-glow-pulse pointer-events-none absolute -inset-2 -z-10 rounded-full bg-sage-400/40 blur-xl"
        />
      )}

      <form
        role="search"
        onSubmit={(e) => e.preventDefault()}
        className={`group relative flex w-full items-center gap-2 rounded-full border bg-white transition-all duration-300 ${
          isLarge ? "px-3 py-2.5 sm:px-4" : "px-2 py-1.5"
        } ${
          focused
            ? "border-sage-400 shadow-soft-lg ring-4 ring-sage-100"
            : "border-sand-200 shadow-soft hover:shadow-soft-lg"
        } ${className}`}
      >
        {showIcon && (
          <span
            className={`flex shrink-0 items-center justify-center rounded-full text-ink-500 transition-colors ${
              focused ? "text-sage-600" : ""
            } ${isLarge ? "h-9 w-9" : "h-7 w-7"}`}
          >
            <SearchIcon className={isLarge ? "h-5 w-5" : "h-4 w-4"} />
          </span>
        )}
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          className={`w-full min-w-0 flex-1 bg-transparent text-ink-900 placeholder:text-ink-300 focus:outline-none ${
            isLarge ? "text-base sm:text-lg" : "text-sm"
          }`}
        />
        <button
          type="submit"
          className={`shrink-0 rounded-full bg-ink-900 font-medium text-cream-50 transition-all duration-300 hover:bg-sage-600 active:scale-95 ${
            isLarge
              ? "px-5 py-2.5 text-sm sm:px-6 sm:text-base"
              : "px-4 py-1.5 text-xs"
          }`}
        >
          {buttonLabel}
        </button>
      </form>
    </div>
  );
}
