"use client";

import { useWishlist } from "@/lib/wishlist-context";
import { HeartIcon } from "./icons";

export default function WishlistButton({
  productId,
  className = "",
}: {
  productId: string;
  className?: string;
}) {
  const { isSaved, toggle } = useWishlist();
  const saved = isSaved(productId);

  return (
    <button
      type="button"
      aria-pressed={saved}
      aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle(productId);
      }}
      className={`flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-ink-700 shadow-soft backdrop-blur-sm transition-all duration-200 hover:scale-110 hover:text-clay-500 active:scale-95 ${
        saved ? "text-clay-500" : ""
      } ${className}`}
    >
      <HeartIcon className="h-[18px] w-[18px]" filled={saved} />
    </button>
  );
}
