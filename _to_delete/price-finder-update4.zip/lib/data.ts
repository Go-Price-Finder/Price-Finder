import { Category, Product, Retailer, RetailerId } from "./types";

export const retailers: Retailer[] = [
  {
    id: "amazon",
    name: "Amazon",
    badgeClass: "bg-[#FF9900]/10 text-[#94620a] ring-1 ring-[#FF9900]/25",
    dotClass: "bg-[#FF9900]",
  },
  {
    id: "walmart",
    name: "Walmart",
    badgeClass: "bg-[#0071CE]/10 text-[#0071CE] ring-1 ring-[#0071CE]/25",
    dotClass: "bg-[#0071CE]",
  },
  {
    id: "etsy",
    name: "Etsy",
    badgeClass: "bg-[#F1641E]/10 text-[#c94f16] ring-1 ring-[#F1641E]/25",
    dotClass: "bg-[#F1641E]",
  },
  {
    id: "target",
    name: "Target",
    badgeClass: "bg-[#CC0000]/10 text-[#CC0000] ring-1 ring-[#CC0000]/25",
    dotClass: "bg-[#CC0000]",
  },
  {
    id: "ebay",
    name: "eBay",
    badgeClass: "bg-ink-900/8 text-ink-700 ring-1 ring-ink-900/15",
    dotClass: "bg-ink-700",
  },
];

export function getRetailer(id: RetailerId): Retailer {
  return retailers.find((r) => r.id === id) ?? retailers[0];
}

/** Builds a 6-month price history that lands on `endPrice`, with a gentle wobble. */
function history(endPrice: number, points: number[]): { date: string; price: number }[] {
  const months = [
    "2026-02-01",
    "2026-03-01",
    "2026-04-01",
    "2026-05-01",
    "2026-06-01",
    "2026-07-01",
  ];
  const series = points.length === months.length ? points : points.concat(endPrice);
  return months.map((date, i) => ({ date, price: series[i] }));
}

export const trendingProducts: Product[] = [
  {
    id: "p1",
    name: "Aria Linen Sofa, 3-Seater",
    category: "Furniture",
    image:
      "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=800&auto=format&fit=crop",
    store: "Amazon",
    retailer: "amazon",
    currentPrice: 1249,
    originalPrice: 1599,
    rating: 4.8,
    reviewCount: 342,
    isBestPrice: true,
    storesTracked: 14,
    priceHistory: history(1249, [1599, 1549, 1499, 1399, 1329, 1249]),
  },
  {
    id: "p2",
    name: "Nordic Oak Coffee Table",
    category: "Furniture",
    image:
      "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=800&auto=format&fit=crop",
    store: "Walmart",
    retailer: "walmart",
    currentPrice: 389,
    originalPrice: 459,
    rating: 4.6,
    reviewCount: 128,
    storesTracked: 9,
    priceHistory: history(389, [429, 429, 459, 419, 399, 389]),
  },
  {
    id: "p3",
    name: "Wireless Noise-Cancelling Headphones",
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
    store: "Amazon",
    retailer: "amazon",
    currentPrice: 279,
    originalPrice: 349,
    rating: 4.7,
    reviewCount: 2140,
    isBestPrice: true,
    storesTracked: 22,
    priceHistory: history(279, [349, 329, 299, 309, 289, 279]),
  },
  {
    id: "p4",
    name: "Ceramic Table Lamp, Warm White",
    category: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=800&auto=format&fit=crop",
    store: "Etsy",
    retailer: "etsy",
    currentPrice: 89,
    rating: 4.9,
    reviewCount: 76,
    storesTracked: 6,
    priceHistory: history(89, [82, 84, 86, 85, 87, 89]),
  },
  {
    id: "p5",
    name: "Everyday Leather Tote Bag",
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=800&auto=format&fit=crop",
    store: "Etsy",
    retailer: "etsy",
    currentPrice: 168,
    originalPrice: 210,
    rating: 4.5,
    reviewCount: 512,
    isBestPrice: true,
    storesTracked: 11,
    priceHistory: history(168, [210, 199, 189, 179, 175, 168]),
  },
  {
    id: "p6",
    name: "Stainless Pour-Over Coffee Set",
    category: "Kitchen",
    image:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=800&auto=format&fit=crop",
    store: "Target",
    retailer: "target",
    currentPrice: 64,
    originalPrice: 82,
    rating: 4.8,
    reviewCount: 903,
    storesTracked: 17,
    priceHistory: history(64, [82, 79, 74, 69, 68, 64]),
  },
  {
    id: "p7",
    name: "Minimalist Running Sneakers",
    category: "Sportswear",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop",
    store: "eBay",
    retailer: "ebay",
    currentPrice: 112,
    originalPrice: 140,
    rating: 4.6,
    reviewCount: 1284,
    isBestPrice: true,
    storesTracked: 19,
    priceHistory: history(112, [140, 135, 129, 119, 118, 112]),
  },
  {
    id: "p8",
    name: "Handwoven Wool Throw Blanket",
    category: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1580301762395-83c5d0e3e3c3?q=80&w=800&auto=format&fit=crop",
    store: "Target",
    retailer: "target",
    currentPrice: 74,
    rating: 4.9,
    reviewCount: 210,
    storesTracked: 8,
    priceHistory: history(74, [69, 71, 73, 72, 73, 74]),
  },
  {
    id: "p9",
    name: "Mechanical Keyboard, Hot-Swappable",
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop",
    store: "Walmart",
    retailer: "walmart",
    currentPrice: 129,
    originalPrice: 159,
    rating: 4.7,
    reviewCount: 664,
    storesTracked: 12,
    priceHistory: history(129, [159, 149, 145, 139, 135, 129]),
  },
  {
    id: "p10",
    name: "Hand-Thrown Ceramic Vase Set",
    category: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?q=80&w=800&auto=format&fit=crop",
    store: "eBay",
    retailer: "ebay",
    currentPrice: 56,
    originalPrice: 68,
    rating: 4.8,
    reviewCount: 94,
    storesTracked: 5,
    priceHistory: history(56, [68, 64, 62, 59, 58, 56]),
  },
];

export const categories: Category[] = [
  {
    id: "c1",
    name: "Furniture",
    image:
      "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?q=80&w=800&auto=format&fit=crop",
    itemCount: "12,400+ items",
  },
  {
    id: "c2",
    name: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=800&auto=format&fit=crop",
    itemCount: "8,900+ items",
  },
  {
    id: "c3",
    name: "Electronics",
    image:
      "https://images.unsplash.com/photo-1498049794561-7780e7231661?q=80&w=800&auto=format&fit=crop",
    itemCount: "21,300+ items",
  },
  {
    id: "c4",
    name: "Fashion",
    image:
      "https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=800&auto=format&fit=crop",
    itemCount: "34,600+ items",
  },
  {
    id: "c5",
    name: "Kitchen & Dining",
    image:
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=800&auto=format&fit=crop",
    itemCount: "9,750+ items",
  },
  {
    id: "c6",
    name: "Beauty & Wellness",
    image:
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop",
    itemCount: "15,200+ items",
  },
];

export function formatPrice(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: value % 1 === 0 ? 0 : 2,
  }).format(value);
}

export function formatShortDate(iso: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    year: "2-digit",
  }).format(new Date(iso));
}

export function analyzePriceHistory(history: Product["priceHistory"]) {
  const prices = history.map((p) => p.price);
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const first = history[0]?.price ?? 0;
  const last = history[history.length - 1]?.price ?? 0;
  const changeAbs = last - first;
  const changePct = first === 0 ? 0 : (changeAbs / first) * 100;
  return {
    min,
    max,
    first,
    last,
    changeAbs,
    changePct,
    isDown: changeAbs < 0,
    isFlat: changeAbs === 0,
  };
}
