"use server";

import { redirect } from "next/navigation";
import { createClient } from "./server";

export type AuthActionResult = { error: string } | void;

const siteUrl = () => process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export async function signUpAction(
  email: string,
  password: string
): Promise<AuthActionResult> {
  if (!email || !password) {
    return { error: "Email and password are required." };
  }
  if (password.length < 6) {
    return { error: "Password must be at least 6 characters." };
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${siteUrl()}/auth/callback`,
    },
  });

  if (error) {
    return { error: error.message };
  }

  if (data.session) {
    // Email confirmation is disabled on this project, so signUp already
    // returned an active session — the user is signed in immediately.
    redirect("/dashboard");
  }

  // Email confirmation is required (the default for new Supabase
  // projects). There's no session yet — nothing more to do until the user
  // clicks the link, which lands on /auth/callback.
  redirect("/auth/login?confirm=1");
}

export async function signInAction(
  email: string,
  password: string,
  redirectTo?: string
): Promise<AuthActionResult> {
  if (!email || !password) {
    return { error: "Email and password are required." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    return { error: error.message };
  }

  // Only ever follow an internal, relative path — redirectTo ultimately
  // comes from a URL query param, so treat it as untrusted input to avoid
  // an open-redirect via something like `//evil.example.com`.
  const isSafeRedirect =
    redirectTo && redirectTo.startsWith("/") && !redirectTo.startsWith("//");

  redirect(isSafeRedirect ? redirectTo : "/dashboard");
}

export async function signOutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
