export type RetailerId = "amazon" | "walmart" | "etsy" | "target" | "ebay";

export type Retailer = {
  id: RetailerId;
  name: string;
  /** Tailwind classes for the small retailer tag shown on product cards */
  badgeClass: string;
  /** Solid-fill Tailwind class used for the small identity dot in the filter dropdown */
  dotClass: string;
};

export type PricePoint = {
  /** ISO date string, e.g. "2026-02-01" */
  date: string;
  price: number;
};

export type Product = {
  id: string;
  name: string;
  category: string;
  image: string;
  store: string;
  storeLogo?: string;
  retailer: RetailerId;
  currentPrice: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  isBestPrice?: boolean;
  storesTracked: number;
  priceHistory: PricePoint[];
};

export type Category = {
  id: string;
  name: string;
  image: string;
  itemCount: string;
};
