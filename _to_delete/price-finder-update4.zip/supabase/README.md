# Supabase setup

This folder holds the database schema for Price Finder's user accounts,
wishlists, and purchase history, plus the auth system built on top of it
(sign up, log in, sessions, a protected dashboard). It's independent of the
loyalty-points system, which will build on top of this once it exists.

## What's here

- `migrations/0001_initial_schema.sql` — the full schema: tables, enum,
  indexes, a spend-summary view, and Row Level Security policies. Fully
  commented with the reasoning behind each choice.
- `seed.sql` — populates `products` from the same catalog the frontend
  already uses (`lib/data.ts`), so wishlists/purchases have real products to
  reference. Safe to re-run.
- `example-queries.sql` — the two queries called out in the original
  requirements ("all purchases by a user", "total spending"), plus a couple
  more, written against the indexes that make them fast.

## One-time setup

1. Create a project at [supabase.com](https://supabase.com) (free tier is
   fine to start).
2. In the Supabase dashboard, open **SQL Editor** and run
   `migrations/0001_initial_schema.sql`, then `seed.sql`. (If you use the
   [Supabase CLI](https://supabase.com/docs/guides/local-development)
   instead, `supabase link` to your project and run `supabase db push`.)
3. In **Settings → API**, copy the **Project URL** and **anon public** key.
4. In the app root, copy `.env.local.example` to `.env.local` and fill in
   `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Leave
   `NEXT_PUBLIC_SITE_URL` as `http://localhost:3000` for local dev; set it
   to your real deployed URL in production.
5. **Auth redirect URL** — in **Authentication → URL Configuration**, add
   `http://localhost:3000/auth/callback` (and your production equivalent)
   to **Redirect URLs**. This is required for the email confirmation link
   Supabase sends on sign-up to work — Supabase rejects redirects to URLs
   not on this list.
6. Restart `npm run dev` so Next.js picks up the new env vars.

That's it — `lib/supabase/client.ts` (browser) and `lib/supabase/server.ts`
(Server Components / Route Handlers / Server Actions) are ready to use, and
`middleware.ts` at the project root keeps auth sessions refreshed.

## Schema overview

| Table | Purpose | Key columns |
|---|---|---|
| `users` | 1:1 profile row per Supabase Auth user | `id` (= `auth.users.id`), `email`, `created_at` |
| `products` | Normalized product catalog | `id`, `name`, `category` |
| `wishlists` | Saved items per user, tagged by retailer | `user_id`, `product_id`, `retailer`, `price_saved` |
| `purchases` | Purchase history, append-only | `user_id`, `product_id`, `retailer`, `amount_spent`, `purchased_at` |

A few decisions worth calling out:

- **No password column, anywhere.** Supabase Auth's built-in `auth.users`
  table already stores email + a securely hashed password + `created_at`,
  and handles verification and password resets. `public.users` is a profile
  row keyed on that same `id` (auto-created by a trigger on signup) — it's
  what the rest of the schema references, but it never touches credentials.
- **Products are normalized**, not duplicated as free text on every
  wishlist/purchase row — both tables reference `products.id` by foreign
  key, which is what makes joins like "my purchases with product names"
  possible without redundant data.
- **Retailer is a Postgres enum** (`amazon`, `walmart`, `etsy`, `target`,
  `ebay`), matching the `RetailerId` type already used in the frontend
  (`lib/types.ts`) — so a bad retailer value is rejected at the database
  level, not just in the UI.
- **Indexing is built around the two queries in the requirements**: a
  composite index on `purchases (user_id, purchased_at desc)` covers "all
  purchases by a user" (already sorted, most recent first) in one index
  scan, and the `user_spending_summary` view pre-expresses the `SUM(...)
  GROUP BY user_id` for total spending. Extra indexes on `product_id` and
  `retailer` support the reporting queries you'll likely want next
  (top-purchased products, spend by retailer).
- **Row Level Security is on for every table.** Each user can only read/
  write their own `users`, `wishlists`, and `purchases` rows; `products` is
  public read-only catalog data. See the policy comments in the migration
  for the one caveat worth knowing about (client-side purchase inserts).
- **Purchases are treated as an append-only ledger** — no update/delete
  policy is granted, so once recorded, a purchase can't be edited or
  deleted by the user.

## Authentication

Built entirely on Supabase Auth — no custom password handling anywhere.

| Route | What it does |
|---|---|
| `/auth/signup` | Email + password sign-up (`components/AuthForm.tsx`) |
| `/auth/login` | Email + password sign-in, same form component |
| `/auth/callback` | Exchanges the email confirmation link's code for a session, then redirects to `/dashboard` |
| `/dashboard` | Server-rendered: profile, total spend, purchase history — redirects to `/auth/login` if signed out |

How the pieces fit together:

- **`lib/supabase/actions.ts`** — Server Actions (`signUpAction`,
  `signInAction`, `signOutAction`) that call `supabase.auth.*` using the
  server client. Sign-up handles both possible project configurations:
  if Supabase returns a session immediately (email confirmation disabled),
  it redirects straight to the dashboard; otherwise it sends the user to
  `/auth/login?confirm=1` to wait for the confirmation email.
- **`lib/auth-context.tsx`** — a client-side `AuthProvider` (wired into
  `app/providers.tsx`) that tracks the current user via
  `supabase.auth.getUser()` on mount and `onAuthStateChange` afterward, so
  the header updates instantly on login/logout and stays in sync across
  tabs. This is what makes the Header's Sign In / Dashboard / Log out state
  reactive without a page reload.
- **`middleware.ts`** — refreshes the session cookie on every request
  (required for Server Components to see a valid session) and redirects
  signed-out visitors away from `/dashboard` before the page even renders.
  `app/dashboard/page.tsx` also checks `auth.getUser()` itself as a second
  layer, in case the page is ever reached another way.
- **Sessions persist across refreshes** because Supabase's `@supabase/ssr`
  client stores the session in cookies (not `localStorage`), which both the
  middleware and server components read on every request — this is what
  "built-in session management" is doing under the hood, not anything
  custom in this app.

## What this doesn't include yet

- **Loyalty points** — intentionally left out per your note; the
  `user_spending_summary` view is the natural foundation to build it on
  (points are usually a function of total or recent spend), but no
  points/tier columns exist yet.
- **Wiring the existing wishlist feature to Supabase** — auth now exists,
  but `lib/wishlist-context.tsx` still uses `localStorage` rather than the
  `wishlists` table / `addToWishlist` / `removeFromWishlist` /
  `getWishlistByUser` helpers in `lib/supabase/queries.ts`. Happy to switch
  that over next now that there's a real signed-in user to attach it to.
- **A UI for recording a purchase** — `recordPurchase` exists in
  `lib/supabase/queries.ts` and the dashboard reads from `purchases`, but
  nothing in the app calls it yet (there's no checkout flow). See the
  security note in the migration about why that insert should eventually
  move server-side.
- **Password reset / forgot-password flow** — not built; Supabase Auth
  supports it (`resetPasswordForEmail`), it just isn't wired up here.
