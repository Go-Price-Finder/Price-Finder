"use client";

import { useState } from "react";
import Link from "next/link";
import Logo from "./Logo";
import SearchBar from "./SearchBar";
import { BellIcon, CloseIcon, MenuIcon } from "./icons";

const NAV_LINKS = [
  { label: "Trending", href: "#trending" },
  { label: "Categories", href: "#categories" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Deals", href: "#" },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-sand-200/70 bg-cream-50/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-5 py-4 sm:px-8">
        <Link href="/" className="shrink-0">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="relative text-sm font-medium text-ink-700 transition-colors hover:text-ink-900 after:absolute after:-bottom-1 after:left-0 after:h-[1.5px] after:w-0 after:bg-sage-500 after:transition-all after:duration-300 hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden max-w-md flex-1 md:block">
          <SearchBar />
        </div>

        <div className="ml-auto hidden items-center gap-3 lg:flex">
          <button
            aria-label="Notifications"
            className="flex h-10 w-10 items-center justify-center rounded-full text-ink-700 transition-colors hover:bg-sand-100 hover:text-ink-900"
          >
            <BellIcon className="h-5 w-5" />
          </button>
          <button className="rounded-full border border-ink-900/10 px-5 py-2.5 text-sm font-medium text-ink-900 transition-all duration-300 hover:border-transparent hover:bg-ink-900 hover:text-cream-50">
            Sign In
          </button>
        </div>

        <button
          aria-label="Toggle menu"
          onClick={() => setMenuOpen((v) => !v)}
          className="ml-auto flex h-10 w-10 items-center justify-center rounded-full text-ink-900 transition-colors hover:bg-sand-100 lg:hidden"
        >
          {menuOpen ? <CloseIcon /> : <MenuIcon />}
        </button>
      </div>

      {/* Mobile search, always visible under 768px */}
      <div className="px-5 pb-4 md:hidden">
        <SearchBar />
      </div>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-out lg:hidden ${
          menuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="flex flex-col gap-1 border-t border-sand-200/70 bg-cream-50 px-5 py-4">
          {NAV_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="rounded-xl px-3 py-3 text-sm font-medium text-ink-700 transition-colors hover:bg-sand-100 hover:text-ink-900"
            >
              {link.label}
            </a>
          ))}
          <button className="mt-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-medium text-cream-50 transition-colors hover:bg-sage-600">
            Sign In
          </button>
        </nav>
      </div>
    </header>
  );
}
