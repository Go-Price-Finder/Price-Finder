import Image from "next/image";
import { Product } from "@/lib/types";
import { formatPrice } from "@/lib/data";
import { StarIcon } from "./icons";

export default function ProductCard({ product }: { product: Product }) {
  const discount =
    product.originalPrice && product.originalPrice > product.currentPrice
      ? Math.round(
          ((product.originalPrice - product.currentPrice) /
            product.originalPrice) *
            100
        )
      : null;

  return (
    <article className="group relative flex w-[260px] shrink-0 flex-col overflow-hidden rounded-3xl border border-sand-200/70 bg-white shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-soft-xl sm:w-[280px]">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-sand-100">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="280px"
          className="object-cover transition-transform duration-500 ease-out group-hover:scale-105"
        />

        {product.isBestPrice && (
          <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-sage-500 px-2.5 py-1 text-[11px] font-semibold text-white shadow-soft">
            <span className="h-1.5 w-1.5 rounded-full bg-white" />
            Best Price
          </span>
        )}

        {discount && (
          <span className="absolute right-3 top-3 rounded-full bg-ink-900/90 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur-sm">
            −{discount}%
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="text-[11px] font-medium uppercase tracking-wide text-ink-300">
          {product.category}
        </span>
        <h3 className="line-clamp-2 font-display text-base font-medium leading-snug text-ink-900">
          {product.name}
        </h3>

        <div className="flex items-center gap-1 text-xs text-ink-500">
          <StarIcon className="h-3.5 w-3.5 text-clay-500" />
          <span className="font-medium text-ink-700">{product.rating}</span>
          <span>({product.reviewCount.toLocaleString()})</span>
        </div>

        <div className="mt-1 flex items-end justify-between">
          <div className="flex items-baseline gap-2">
            <span
              className={`font-display text-xl font-semibold ${
                product.isBestPrice ? "text-sage-600" : "text-ink-900"
              }`}
            >
              {formatPrice(product.currentPrice)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-ink-300 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>
        </div>

        <div className="mt-1 flex items-center justify-between border-t border-sand-100 pt-3 text-xs text-ink-500">
          <span>
            at <span className="font-medium text-ink-700">{product.store}</span>
          </span>
          <span>{product.storesTracked} stores</span>
        </div>
      </div>
    </article>
  );
}
