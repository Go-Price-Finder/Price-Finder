import { Category, Product } from "./types";

export const trendingProducts: Product[] = [
  {
    id: "p1",
    name: "Aria Linen Sofa, 3-Seater",
    category: "Furniture",
    image:
      "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=800&auto=format&fit=crop",
    store: "Dwell & Co",
    currentPrice: 1249,
    originalPrice: 1599,
    rating: 4.8,
    reviewCount: 342,
    isBestPrice: true,
    storesTracked: 14,
  },
  {
    id: "p2",
    name: "Nordic Oak Coffee Table",
    category: "Furniture",
    image:
      "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=800&auto=format&fit=crop",
    store: "Maison Studio",
    currentPrice: 389,
    originalPrice: 459,
    rating: 4.6,
    reviewCount: 128,
    storesTracked: 9,
  },
  {
    id: "p3",
    name: "Wireless Noise-Cancelling Headphones",
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
    store: "TechNest",
    currentPrice: 279,
    originalPrice: 349,
    rating: 4.7,
    reviewCount: 2140,
    isBestPrice: true,
    storesTracked: 22,
  },
  {
    id: "p4",
    name: "Ceramic Table Lamp, Warm White",
    category: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=800&auto=format&fit=crop",
    store: "Lumen Home",
    currentPrice: 89,
    rating: 4.9,
    reviewCount: 76,
    storesTracked: 6,
  },
  {
    id: "p5",
    name: "Everyday Leather Tote Bag",
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=800&auto=format&fit=crop",
    store: "Ateliér",
    currentPrice: 168,
    originalPrice: 210,
    rating: 4.5,
    reviewCount: 512,
    isBestPrice: true,
    storesTracked: 11,
  },
  {
    id: "p6",
    name: "Stainless Pour-Over Coffee Set",
    category: "Kitchen",
    image:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=800&auto=format&fit=crop",
    store: "Brew Supply Co",
    currentPrice: 64,
    originalPrice: 82,
    rating: 4.8,
    reviewCount: 903,
    storesTracked: 17,
  },
  {
    id: "p7",
    name: "Minimalist Running Sneakers",
    category: "Sportswear",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop",
    store: "Stride Athletics",
    currentPrice: 112,
    originalPrice: 140,
    rating: 4.6,
    reviewCount: 1284,
    isBestPrice: true,
    storesTracked: 19,
  },
  {
    id: "p8",
    name: "Handwoven Wool Throw Blanket",
    category: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1580301762395-83c5d0e3e3c3?q=80&w=800&auto=format&fit=crop",
    store: "Wildflower Living",
    currentPrice: 74,
    rating: 4.9,
    reviewCount: 210,
    storesTracked: 8,
  },
];

export const categories: Category[] = [
  {
    id: "c1",
    name: "Furniture",
    image:
      "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?q=80&w=800&auto=format&fit=crop",
    itemCount: "12,400+ items",
  },
  {
    id: "c2",
    name: "Home Decor",
    image:
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=800&auto=format&fit=crop",
    itemCount: "8,900+ items",
  },
  {
    id: "c3",
    name: "Electronics",
    image:
      "https://images.unsplash.com/photo-1498049794561-7780e7231661?q=80&w=800&auto=format&fit=crop",
    itemCount: "21,300+ items",
  },
  {
    id: "c4",
    name: "Fashion",
    image:
      "https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=800&auto=format&fit=crop",
    itemCount: "34,600+ items",
  },
  {
    id: "c5",
    name: "Kitchen & Dining",
    image:
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=800&auto=format&fit=crop",
    itemCount: "9,750+ items",
  },
  {
    id: "c6",
    name: "Beauty & Wellness",
    image:
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop",
    itemCount: "15,200+ items",
  },
];

export function formatPrice(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: value % 1 === 0 ? 0 : 2,
  }).format(value);
}
