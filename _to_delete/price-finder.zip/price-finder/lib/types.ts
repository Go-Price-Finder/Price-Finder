export type Product = {
  id: string;
  name: string;
  category: string;
  image: string;
  store: string;
  storeLogo?: string;
  currentPrice: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  isBestPrice?: boolean;
  storesTracked: number;
};

export type Category = {
  id: string;
  name: string;
  image: string;
  itemCount: string;
};
